#ifdef MASTERPRO
#include<espnow.h>
#include<FirebaseESP8266.h>
#define NO_OF_NODES 2

uint8_t receiverAddress1[6] = {0x40, 0xf5, 0x20, 0x17, 0x71, 0xba};

struct __attribute__((packed)) room
{
  uint8_t MacAddress;
  byte noOfLights;
  byte noOfFans;
  byte noOfOtherApp;
       
};

room node[2];

void setupNodes()
{
    node[0].MacAddress=receiverAddress1;
    
}

#endif