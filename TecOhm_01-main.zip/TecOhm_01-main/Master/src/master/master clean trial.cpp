#ifdef MASTER
#include <FirebaseESP8266.h>
#include <ESP8266WiFi.h>
#include <espnow.h>

#define FIREBASE_HOST "https://tecohm-13502.firebaseio.com"
#define API_KEY "labtfoigGT3kjjCSUk42NRn6VkCJMJRQy1FkkO3C"
#define PARENT_PATH "/tecohm-13502/"

#define NO_OF_LIGHTS 2
#define NO_OF_FANS 0

#define MY_NAME "MASTER"
#define MY_ROLE ESP_NOW_ROLE_COMBO
#define RECEIVER_ROLE ESP_NOW_ROLE_COMBO

const int totalApp = NO_OF_LIGHTS + NO_OF_FANS;
String appliancesKey[totalApp];
String currentStatus[totalApp];
volatile bool isReceivedDataFromEspCB = false, isDataSentToEsp = false;

FirebaseData firebaseData; //firebasedata

uint8_t receiverAddress[] = {0x40, 0xf5, 0x20, 0x17, 0x71, 0xba}; //add reciver mac ids

struct __attribute__((packed)) StructApplianceData
{
  int8_t index;
  int8_t status;
};

  StructApplianceData applianceDataRecvFromESPSlave;

void onDataSentCB(uint8_t *receiver_mac, uint8_t transmissionStatus)
{
  if (transmissionStatus == 0)
  {
    Serial.printf("\nData sent successfully from Master to Slave");
    isDataSentToEsp = true;
  }
  else
  {
    Serial.printf("\nError code in transmission complete: ");
    Serial.println(transmissionStatus);
  }
}

void sendDataToFirebase()
{
  FirebaseJson jsonDataForEachAppliance;
  const int pacIndexFromEsp = applianceDataRecvFromESPSlave.index + 1;
  const String stateOfAppliance = String(applianceDataRecvFromESPSlave.status);
  jsonDataForEachAppliance.add("LED" + String(pacIndexFromEsp) + "_Status", stateOfAppliance);

  // TODO: move this to a separate func called printJson(FirebaseJson json);
  String jsonStr;
  jsonDataForEachAppliance.toString(jsonStr, true);
  Serial.println(jsonStr);

  if (Firebase.updateNode(firebaseData, PARENT_PATH, jsonDataForEachAppliance))
  {
    Serial.println(firebaseData.dataPath());
    currentStatus[applianceDataRecvFromESPSlave.index] = String(applianceDataRecvFromESPSlave.status);
  }
  else
  {
    Serial.printf("\nFailed in pushing json");
    Serial.println(firebaseData.errorReason());
  }
  Firebase.reconnectWiFi(true);
}

void onDataRecvCB(uint8_t *senderMac, uint8_t *data, uint8_t dataLength)
{

  Serial.printf("\nIn ESP sent CB");
  char macStr[18];

  snprintf(macStr, sizeof(macStr), "%02x:%02x:%02x:%02x:%02x:%02x", senderMac[0], senderMac[1], senderMac[2], senderMac[3], senderMac[4], senderMac[5]);

  Serial.printf("\nReceived data from: ");
  Serial.println(macStr);

  memcpy(&applianceDataRecvFromESPSlave, data, sizeof(applianceDataRecvFromESPSlave));
  
Serial.print("Appliance Data Index: " + String(applianceDataRecvFromESPSlave.index) + "\nAppliance Data Status: " + String(applianceDataRecvFromESPSlave.status));

  isReceivedDataFromEspCB = true;
}

void wifiConnect()
{

  WiFi.begin("tecohm", "micro8266");
  Serial.printf("\nConnecting..");
  while (WiFi.status() != WL_CONNECTED)
  {
    Serial.println('.');
    delay(1000);
  }
}

void initESPNow()
{
  if (esp_now_init() != 0)
  {
    Serial.printf("\nESP-NOW initialization failed");
    return;
  }
  esp_now_set_self_role(MY_ROLE);
  esp_now_register_send_cb(onDataSentCB);
  esp_now_register_recv_cb(onDataRecvCB);
  esp_now_add_peer(receiverAddress, RECEIVER_ROLE, 1, NULL, 0);
  Serial.println("Initialized.");
}

void setup()
{
  Serial.begin(74880);
  for (int i = 0; i < totalApp; ++i)
  {
    currentStatus[i] = "0";
  }
  Serial.printf("\nInitializing...");
  Serial.println(MY_NAME);
  Serial.printf("\nMy MAC address is: ");
  Serial.println(WiFi.macAddress());

  WiFi.mode(WIFI_AP_STA);
  WiFi.disconnect();
  WiFi.softAP("ssid", "password", 1);
  IPAddress myIP = WiFi.softAPIP();
  Serial.print("AP IP address: ");
  Serial.println(myIP);

  wifiConnect();

  Serial.println("");
  Serial.println("WiFi connected.");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
  // const int WIFI_CHANNEL = WiFi.channel();
  Serial.println(WiFi.channel());

  Firebase.begin(FIREBASE_HOST, API_KEY);
  Firebase.reconnectWiFi(true);
  
  initESPNow();
  
  /* TODO optimize using snprintf_p https://cpp4arduino.com/2020/02/07/how-to-format-strings-without-the-string-class.html
  move to a sep function called buildAppliances
  */
  for (int i = 0; i < totalApp; ++i)
  {
    const String indexOfAppliance = String(i + 1);
    const String currentAppliance = i < NO_OF_LIGHTS ? "LED" : "FAN";
    appliancesKey[i] = PARENT_PATH + currentAppliance + indexOfAppliance + "_Status";
    Serial.println(appliancesKey[i]);
  }
}

void sendRealTimeDataToEspSlave(String realTimeValueReceived, int i)
{
  Serial.println("GPIO 4, on");
  StructApplianceData apllianceDataForESPSlave;
  int Status = realTimeValueReceived == "1" ? 1 : 0;
  apllianceDataForESPSlave.index = i;
  apllianceDataForESPSlave.status = Status;
  Serial.println(apllianceDataForESPSlave.index);
  Serial.println(apllianceDataForESPSlave.status);
  while (isDataSentToEsp == false)
  {
    esp_now_send(receiverAddress, (uint8_t *)&apllianceDataForESPSlave, sizeof(apllianceDataForESPSlave));
    delay(100);
  }
  isDataSentToEsp = false;
}

void loop()
{
  /*
  #TODO: When our esp sends back data, we set a global variable
  receivedDataFromEspCallback=1. This is a workaround to avoid
  wdt reset in microcontroller. Ideally this section should be
  handled within the registered callback of esp-now
  */
  if (isReceivedDataFromEspCB)
  {
    Serial.println("entered");
    delay(100);
    sendDataToFirebase();
    isReceivedDataFromEspCB = false;
  }

  /* TODO: We should use Firebase getJson and avoid loops
  if (Firebase.getJSON(firebaseData, "/TecOhmApp_01")) {
    FirebaseJson &json = firebaseData.jsonObject();
    FirebaseJsonData data;
    json.get(data, "/path/to/node");
  }
  */
  for (int i = 0; i < totalApp; ++i)
  {
    if (WiFi.status() != WL_CONNECTED)
    {
      wifiConnect();
    }
    Firebase.getString(firebaseData, appliancesKey[i]);
    const String ledStatusFromFireBase = firebaseData.stringData();
    if (currentStatus[i] != ledStatusFromFireBase)
    {
      Serial.println(i);
      currentStatus[i] = ledStatusFromFireBase;
      Serial.println(ledStatusFromFireBase);
      sendRealTimeDataToEspSlave(ledStatusFromFireBase, i);
    }
  }
  delay(100);
}
#endif
