#ifdef MASTER5
#include <FirebaseESP8266.h>
#include <ESP8266WiFi.h>
#include <espnow.h>

#define FIREBASE_HOST "https://tecohm-13502.firebaseio.com"
#define API_KEY "labtfoigGT3kjjCSUk42NRn6VkCJMJRQy1FkkO3C"

#define NO_OF_LIGHTS 2
#define NO_OF_FANS 0

#define MY_NAME "MASTER"
#define MY_ROLE ESP_NOW_ROLE_COMBO
#define RECEIVER_ROLE ESP_NOW_ROLE_COMBO

const int totalApp = NO_OF_LIGHTS + NO_OF_FANS;
String appliances[totalApp];
String stat[2] = {"0", "0"};
volatile int receivedDataFromEspCallback = 0;

FirebaseData firebaseData, firebaseData2; //firebasedata

uint8_t receiverAddress[] = {0x40, 0xf5, 0x20, 0x17, 0x71, 0xba}; //add reciver mac ids

struct __attribute__((packed)) dataPacket
{
  int pin_no;
  int command;
};
struct __attribute__((packed)) updatefirebase
{
  int light_status;
  int appliance_no;
};
volatile updatefirebase pac;

void transmissionComplete(uint8_t *receiver_mac, uint8_t transmissionStatus)
{
  if (transmissionStatus == 0)
  {
    Serial.println("Data sent successfully");
  }
  else
  {
    Serial.print("Error code: ");
    Serial.println(transmissionStatus);
  }
}

void sendDataToFriebase()
{
  //  Firebase.getString(firebaseData2, appliances[0]);
  //   const String ledStatusFromFireBase = firebaseData2.stringData();
  //   Serial.println("sucess");
  //   Serial.println(ledStatusFromFireBase);
  if (Firebase.setString(firebaseData2, "/TecOhm_TestApp01/LED2_Status", String(pac.light_status)))
  {
    Serial.println(firebaseData2.dataPath());
    stat[pac.appliance_no]=String(pac.light_status);

    //Serial.println(firebaseData2.pushName());

    // Serial.println(firebaseData.dataPath() + "/TecOhm_TestApp01/LED1_Status" + firebaseData.pushName());
  }
  else
  {
    Serial.println("Failed in pushing json");
    Serial.println(firebaseData2.errorReason());
  }
  Firebase.reconnectWiFi(true);
}
void dataRecived(uint8_t *senderMac, uint8_t *data, uint8_t dataLength)
{ delay(1000);
  char macStr[18];
  updatefirebase pack;

  snprintf(macStr, sizeof(macStr), "%02x:%02x:%02x:%02x:%02x:%02x", senderMac[0], senderMac[1], senderMac[2], senderMac[3], senderMac[4], senderMac[5]);

  Serial.println();
  Serial.print("Received data from: ");
  Serial.println(macStr);

  memcpy(&pack, data, sizeof(pack));
  delay(2500);
  pac.appliance_no=pack.appliance_no;
  pac.light_status=pack.light_status;
  Serial.print(pac.appliance_no);
  Serial.print(pac.light_status);
   //sendDataToFriebase();

  receivedDataFromEspCallback = 1;
  
  //  FirebaseJson json;
  //  json.add(String(pac.light_status));
  //  Serial.println(" ");
  //  Serial.println(WiFi.status()!= WL_CONNECTED);
  // //  if(WiFi.status()!= WL_CONNECTED)
  //  Firebase.reconnectWiFi(true);

  //  if (Firebase.setString(firebaseData2, "/TecOhm_TestApp01/LED1_Status", "1"))
  //   {
  //     Serial.println(firebaseData2.dataPath());

  //     Serial.println(firebaseData2.pushName());

  //     // Serial.println(firebaseData.dataPath() + "/TecOhm_TestApp01/LED1_Status" + firebaseData.pushName());
  //   }
  //   else
  //   {
  //      Serial.println("Failed in pushing json");
  //     Serial.println(firebaseData2.errorReason());
  //   }
}

void wifiConnect()
{

  WiFi.begin("tecohm", "micro8266");
  Serial.println("Connecting..");
  while (WiFi.status() != WL_CONNECTED)
  {
    Serial.println('.');
    delay(1000);
  }
}

void setup()
{
  Serial.begin(115200);

  Serial.print("\n\nInitializing...");
  Serial.println(MY_NAME);
  Serial.print("My MAC address is: ");
  Serial.println(WiFi.macAddress());

  WiFi.mode(WIFI_AP_STA);
  WiFi.disconnect();
// WiFi.softAP()
  WiFi.softAP("ssid", "password",1);
  IPAddress myIP = WiFi.softAPIP();
  Serial.print("AP IP address: ");
  Serial.println(myIP);

  wifiConnect();

  Serial.println("");
  Serial.println("WiFi connected.");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
  // const int WIFI_CHANNEL = WiFi.channel();
  Serial.println(WiFi.channel());

  Firebase.begin(FIREBASE_HOST, API_KEY);
  Firebase.reconnectWiFi(true);

  if (esp_now_init() != 0)
  {
    Serial.println("ESP-NOW initialization failed");
    return;
  }

  esp_now_set_self_role(MY_ROLE);
  esp_now_register_send_cb(transmissionComplete);
  esp_now_register_recv_cb(dataRecived);

  esp_now_add_peer(receiverAddress, RECEIVER_ROLE, 1, NULL, 0);

  Serial.println("Initialized.");

  // TODO optimize using snprintf_p https://cpp4arduino.com/2020/02/07/how-to-format-strings-without-the-string-class.html
  for (int i = 0; i < totalApp; ++i)
  {
    const String indexOfAppliance = String(i + 1);
    const String currentAppliance = i < NO_OF_LIGHTS ? "LED" : "FAN";
    appliances[i] = "/TecOhm_TestApp01/" + currentAppliance + indexOfAppliance + "_Status";
    Serial.println(appliances[i]);
  }
}

void sendRealTimeDataToEspSlave(String realTimeValueReceived, int i)
{
  if (i == 0)
  {
    Serial.println("GPIO 4, on");
    dataPacket packet;
    int Status = realTimeValueReceived == "1" ? 1 : 0;
    packet.pin_no = 1;
    packet.command = Status;
    esp_now_send(receiverAddress, (uint8_t *)&packet, sizeof(packet));
  }
  else
  {
    Serial.println("GPIO 2 , on");
    dataPacket packet;
    int Status = realTimeValueReceived == "1" ? 1 : 0;
    packet.pin_no = 2;
    packet.command = Status;
    esp_now_send(receiverAddress, (uint8_t *)&packet, sizeof(packet));
    delay(1000);
  }
}

void loop()
{

  if(receivedDataFromEspCallback == 1) {
    Serial.println("entered");
    delay(100);
    sendDataToFriebase();
    receivedDataFromEspCallback = 0;
  }
  for (int i = 0; i < totalApp; ++i)
  {

    if (WiFi.status() != WL_CONNECTED)
      wifiConnect();
    Firebase.getString(firebaseData, appliances[i]);
    const String ledStatusFromFireBase = firebaseData.stringData();
    if (stat[i] != ledStatusFromFireBase)
    {
      Serial.println(1);
      stat[i] = ledStatusFromFireBase;
      Serial.println(ledStatusFromFireBase);
      sendRealTimeDataToEspSlave(ledStatusFromFireBase, i);
    }
  }
  delay(100);
}
#endif