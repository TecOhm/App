#ifdef MASTER0
#include <FirebaseESP8266.h>
#include <ESP8266WiFi.h>
#include <espnow.h>

#define FIREBASE_HOST "https://tecohm-13502.firebaseio.com"
#define API_KEY "labtfoigGT3kjjCSUk42NRn6VkCJMJRQy1FkkO3C"

#define NO_OF_LIGHTS 2
#define MY_NAME "MASTER"
#define MY_ROLE ESP_NOW_ROLE_COMBO
#define RECEIVER_ROLE ESP_NOW_ROLE_COMBO

const int totalapp = NO_OF_LIGHTS;
String appliances[totalapp];

int WIFI_CHANNEL;
const int pin2 = 2;
const int pin4 = 4;

FirebaseData firebasedata;

uint8_t receiverAddress[] = {0x40, 0xf5, 0x20, 0x17, 0x71, 0xba};
//EE:FA:BC:C3:A1:11

struct updatefirebase
{
  String flag;
  int applianceNumber;
};

struct __attribute__((packed)) dataPacket
{
  int a;
  int b;
};

void dataRecived(uint8_t *senderMac, uint8_t *data, uint8_t dataLength)
{
  char macStr[18];
  updatefirebase pac;

  snprintf(macStr, sizeof(macStr), "%02x:%02x:%02x:%02x:%02x:%02x", senderMac[0], senderMac[1], senderMac[2], senderMac[3], senderMac[4], senderMac[5]);

  Serial.println();
  Serial.print("Received data from: ");
  Serial.println(macStr);

  memcpy(&pac, data, sizeof(pac));
  Serial.print(pac.applianceNumber);
  Serial.print(pac.flag);

  FirebaseJson jsonParent, jsonChild;
  jsonChild.add("LED" + String(pac.applianceNumber + 1) + "_Status", pac.flag);
  // jsonParent.add("TecOhm_TestApp01", jsonChild);
  // jsonChild.add("LED2_Status", "0");
  // jsonParent.add("TecOhm_TestApp01", jsonChild);
  // Serial.print("sending to firebase");
  // String jsonStr;
  // jsonParent.toString(jsonStr, true);
  // Serial.println(jsonStr);

  if (Firebase.setJSON(firebasedata, "/TecOhm_TestApp01/LED1_Status", jsonChild))
  {
    Serial.println(firebasedata.dataPath());

    Serial.println(firebasedata.pushName());

    Serial.println(firebasedata.dataPath() + "/TecOhm_TestApp01/LED1_Status" + firebasedata.pushName());
  }
  else
  {
     Serial.println("Failed in pushing json");
    Serial.println(firebasedata.errorReason());
  }
  // jsonParent.clear();
  jsonChild.clear();
  delay(4000);
}

void transmissionComplete(uint8_t *receiver_mac, uint8_t transmissionStatus)
{
  if (transmissionStatus == 0)
  {
    Serial.println("Data sent successfully");
  }
  else
  {
    Serial.print("Error code: ");
    Serial.println(transmissionStatus);
  }
}

void setup()
{
  Serial.begin(115200);

  Serial.println();
  Serial.println();
  Serial.print("Initializing...");
  Serial.println(MY_NAME);
  Serial.print("My MAC address is: ");
  Serial.println(WiFi.macAddress());

  WiFi.mode(WIFI_AP_STA);
  WiFi.disconnect();
   WiFi.softAP("ssid", "password");
  IPAddress myIP = WiFi.softAPIP();
  Serial.print("AP IP address: ");
  Serial.println(myIP);
  WiFi.begin("123456", "9995393373");

  Serial.println("Connecting..");
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(1000);
    Serial.println('.');
  }

  Serial.println("");
  Serial.println("WiFi connected.");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
  WIFI_CHANNEL = WiFi.localIP();
  Serial.println(WiFi.channel());

  Firebase.begin(FIREBASE_HOST, API_KEY);
 Firebase.reconnectWiFi(true);
  if (esp_now_init() != 0)
  {
    Serial.println("ESP-NOW initialization failed");
    return;
  }

  esp_now_set_self_role(MY_ROLE);
  esp_now_register_send_cb(transmissionComplete);
  esp_now_register_recv_cb(dataRecived);

  esp_now_add_peer(receiverAddress, RECEIVER_ROLE, WIFI_CHANNEL, NULL, 0);

  Serial.println("Initialized.");

  // TODO optimize using snprintf_p https://cpp4arduino.com/2020/02/07/how-to-format-strings-without-the-string-class.html
  for (int i = 0; i < totalapp; ++i)
  {
    const String indexOfAppliance = String(i + 1);
    const String currentAppliance = i < 4 ? "LED" : "FAN";
    appliances[i] = "/TecOhm_TestApp01/" + currentAppliance + indexOfAppliance + "_Status";
    Serial.println(appliances[i]);
  }

 
}

void sendRealTimeDataToEspSlave(String realTimeValueReceived, int i)
{
  if (i == 0)
  {
    Serial.println("GPIO 4, on");
    dataPacket packet;
    int Status = realTimeValueReceived == "1" ? 1 : 0;
    packet.a = 4;
    packet.b = Status;
    esp_now_send(receiverAddress, (uint8_t *)&packet, sizeof(packet));
  }
  else
  {
    Serial.println("GPIO 2 , on");
    dataPacket packet;
    int Status = realTimeValueReceived == "1" ? 1 : 0;
    packet.a = 2;
    packet.b = Status;
    esp_now_send(receiverAddress, (uint8_t *)&packet, sizeof(packet));
  }
}

void loop()
{
  // String stat[2] = {"0", "0"};
  // for (int i = 0; i < totalapp; ++i)
  // {

  //   Firebase.getString(firebasedata, appliances[i]);
  //   const String ledStatusFromFireBase = firebasedata.stringData();
  //   if (stat[i] != ledStatusFromFireBase)
  //   {
  //     Serial.println(1);
  //     stat[i] = ledStatusFromFireBase;
  //     Serial.println(ledStatusFromFireBase);
  //     sendRealTimeDataToEspSlave(ledStatusFromFireBase, i);
  //   }
  // }
  delay(100);
}
#endif