#ifdef MASTER1
#include <FirebaseESP8266.h>
#include <ESP8266WiFi.h>


#define FIREBASE_HOST "https://tecohm-13502.firebaseio.com"
#define API_KEY "labtfoigGT3kjjCSUk42NRn6VkCJMJRQy1FkkO3C"

FirebaseData firebaseData,firebaseData2;   

void wifiConnect()
{
   
        WiFi.begin("123456", "9995393373");
        Serial.println("Connecting..");
        while (WiFi.status() != WL_CONNECTED)
        { 
          Serial.println('.');
          delay(1000);
        }
      
}
void setup()
{
  Serial.begin(115200);

  Serial.print("\n\nInitializing...");
  //Serial.println(MY_NAME);
  Serial.print("My MAC address is: ");
  Serial.println(WiFi.macAddress());

  WiFi.mode(WIFI_AP_STA);
  WiFi.disconnect();
  
  WiFi.softAP("ssid", "password");
  IPAddress myIP = WiFi.softAPIP();
  Serial.print("AP IP address: ");
  Serial.println(myIP);

  wifiConnect();
  

  Serial.println("");
  Serial.println("WiFi connected.");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
  const int WIFI_CHANNEL = WiFi.channel();
  Serial.println(WiFi.channel());


  Firebase.begin(FIREBASE_HOST, API_KEY);
  Firebase.reconnectWiFi(true);
  
}

void loop()
{FirebaseJson json;
 //json.add("1");

 if (Firebase.setString(firebaseData2, "/TecOhm_TestApp01/LED1_Status", "1"))
  {
    Serial.println(firebaseData2.dataPath());

    Serial.println(firebaseData2.pushName());

    // Serial.println(firebaseData.dataPath() + "/TecOhm_TestApp01/LED1_Status" + firebaseData.pushName());
  }
  else
  {
     Serial.println("Failed in pushing json");
    Serial.println(firebaseData2.errorReason());
  }
  //delay(2500);
}
#endif