#include <ESP8266WiFi.h>
#include <espnow.h>

#define MY_NAME "SLAVE_ROOM_X"
#define NO_OF_LIGHTS 1 
#define NO_OF_FANS 1
#define NO_OF_APPLIENCE 0
const int8_t totalApp=NO_OF_FANS+NO_OF_LIGHTS+NO_OF_APPLIENCE;
unsigned long previousTime=0;

// PIN CONFIG
const byte pins[10]= {3,10,15,0,5,4,14,12,13,9};
byte light[NO_OF_LIGHTS],fan[NO_OF_FANS],otherAplliance[NO_OF_APPLIENCE];
byte switchPins[totalApp],outputApp[totalApp];
int8_t applienceCurrentStatus[totalApp],switchState[totalApp];

volatile int8_t espSent=0;

int8_t WifiChannel;

void initializePins()
{
  int8_t j=0,i=0;
  for (i=0;i<totalApp&&j<5;++i)
  {
    outputApp[i] = pins[j++];
    pinMode(outputApp[i], OUTPUT); 
   if(i<NO_OF_LIGHTS)
   {
     Serial.print("light ");
     Serial.println(i);
     Serial.println(outputApp[i]);
     
    }
   else if(i<NO_OF_LIGHTS+NO_OF_FANS)
   {
     Serial.print("fan ");
     Serial.println(i-NO_OF_LIGHTS);
     Serial.println(outputApp[i]);
    }
   else
   {
     Serial.print("other ");
     Serial.println(i-NO_OF_LIGHTS+NO_OF_FANS);
     Serial.print("stat");
     Serial.println(outputApp[i]);
   }
  }
  j=5;        
  for(i=0;i<totalApp&&j<12;++i)
  {
    switchPins[i]=pins[j++];
    Serial.println(switchPins[i]);
    pinMode(switchPins[i],INPUT);
    if(i<NO_OF_LIGHTS)
    {
     Serial.print("light ");
     Serial.println(i);
     Serial.println(switchPins[i]);
    }
    else if(i<NO_OF_LIGHTS+NO_OF_FANS)
    {
     Serial.print("fan ");
     Serial.println(i-NO_OF_LIGHTS);
     Serial.println(switchPins[i]);
    }
    else
    {
     Serial.print("other ");
     Serial.println(i-NO_OF_LIGHTS+NO_OF_FANS);
     Serial.print("stat");
     Serial.println(switchPins[i]);
       }
  }
}

void initSwitchState()
{
  for(int8_t i=0;i<totalApp;++i)
  {
    switchState[i]= digitalRead(switchPins[i]);
    Serial.print("switch1=");
    Serial.println(switchState[i]);
  }
}


// WIFI config
void connectToWifi()
{
    // WiFi.disconnect(); // we do not want to connect to a WiFi network
    WiFi.begin("ssid", "password");
    Serial.println("Connecting..");
    while (WiFi.status() != WL_CONNECTED)
    {
        delay(1000);
        Serial.println('.');
    }
    Serial.println("\nWiFi connected.\nIP address: ");
    Serial.println(WiFi.localIP());
    WifiChannel=WiFi.channel();
    Serial.println(WifiChannel);
}

// FIREBASE CONFIG

byte firebaseStatus[NO_OF_LIGHTS+NO_OF_FANS+NO_OF_APPLIENCE];

void initializeFirebaseStaus()
{
  for(int8_t i=0;i<totalApp;++i)
   {firebaseStatus[i]=0;
    applienceCurrentStatus[i]=0;
   } 
}

// ESP_NOW CONFIG


#define MY_ROLE ESP_NOW_ROLE_COMBO
#define RECEIVER_ROLE ESP_NOW_ROLE_COMBO


uint8_t masterAddress[] = {0xec, 0xfa, 0xbc, 0xc3, 0xa1, 0x11};


struct __attribute__((packed)) dataPacket
{
    int8_t index;
    int8_t status;
};

void transmissioncomplete (uint8_t *recieverMac, uint8_t transmissionStatus)
{
    if (transmissionStatus == 0)
    {
        Serial.println("data send sucessfully");
        espSent=1;
    }
    else
    {
        Serial.println("error");
    }
}


void dataReceived(uint8_t *senderMac, uint8_t *data, uint8_t dataLength)
{
  char macStr[18];
  dataPacket packet;

  snprintf(macStr, sizeof(macStr), "%02x:%02x:%02x:%02x:%02x:%02x", senderMac[0], senderMac[1], senderMac[2], senderMac[3], senderMac[4], senderMac[5]);

  memcpy(&packet, data, sizeof(packet));
   // Serial.print("/nReceived data from: ");
    // Serial.println(macStr);
  int8_t i;
  for( i=0;i<totalApp;++i) 
  {
    if(i==packet.index)
   {Serial.println(firebaseStatus[i]);
    Serial.println( packet.status);
      if (firebaseStatus[i] != packet.status)
      {
        if (packet.status != 0)
        digitalWrite(outputApp[i], HIGH);
        else
        digitalWrite(outputApp[i], LOW);
        Serial.println(outputApp[i]);
        applienceCurrentStatus[i] = packet.status;
        firebaseStatus[i] = packet.status;
        Serial.print("/nReceived data from: ");
        Serial.println(macStr);
        if(i<NO_OF_LIGHTS)
        {
          Serial.print("light ");
          Serial.println(i);
          Serial.print("stat");
          Serial.println(applienceCurrentStatus[i]);
        }    
        else if(i<NO_OF_LIGHTS+NO_OF_FANS)
        {
          Serial.print("fan ");
          Serial.println(i-NO_OF_LIGHTS);
          Serial.print("stat");
          Serial.println(applienceCurrentStatus[i]);
        }
        else
        {
          Serial.print("other ");
          Serial.println(i-NO_OF_LIGHTS+NO_OF_FANS);
          Serial.print("stat");
          Serial.println(applienceCurrentStatus[i]);
        }
      }
    } 
    unsigned long currentTime=millis();
    previousTime=currentTime;
    while(previousTime-currentTime<2500)
     currentTime=millis();
  }
  
}

void initEspNow()
{
    if (esp_now_init() != 0)
    {
        Serial.println("ESP-NOW initialization failed");
        return;
    }
    esp_now_set_self_role(MY_ROLE);
  esp_now_register_send_cb(transmissioncomplete);
  esp_now_register_recv_cb(dataReceived);

  esp_now_add_peer(masterAddress, RECEIVER_ROLE, WifiChannel, NULL, 0);
    Serial.println("Initialized.");
}

// Switch read data
void readSwitch ()
{
  unsigned long currentTime=millis();
  previousTime=currentTime;
  int8_t currentState,i;
  dataPacket pac;
  for(i=0;i<totalApp;++i)
  {
    currentState=digitalRead(switchPins[i]);
    // Serial.println(i);
    // Serial.println(currentState);
    // Serial.println(switchState[i]);

    while(currentTime-previousTime<500)
      currentTime=millis();
      
    if(switchState[i]!=currentState)
    {
      if(applienceCurrentStatus[i]!=0)
      {
        digitalWrite(outputApp[i],LOW);
        applienceCurrentStatus[i]=0;
      }  
      else
      { digitalWrite(outputApp[i],HIGH);
        applienceCurrentStatus[i]=1;
      }
      switchState[i]=currentState;
      firebaseStatus[i]=applienceCurrentStatus[i];
      pac.index=i;
      pac.status=applienceCurrentStatus[i];
      while(espSent==0)
      {esp_now_send(masterAddress, (uint8_t *)&pac, sizeof(pac));
      delay(100);
      }
      espSent=0;
      Serial.println("sent");
      currentTime=millis();
      previousTime=currentTime;
      while(currentTime-previousTime<500)
      currentTime=millis();

    }
    previousTime=currentTime;
  }
}


void setup()
{
  Serial.begin(74880); // initialize serial port
  initializePins();
  // switchPins[0]=D7;
  // switchPins[1]=D8;  
  // pinMode(12,INPUT);
  // pinMode(9,INPUT);
  // pinMode(4,INPUT);
  // pinMode(13,INPUT);  
  // pinMode(14,INPUT); 
  initSwitchState();
  initializeFirebaseStaus();
//  pinMode(3,INPUT);
//  digitalWrite(3,LOW);
  Serial.print("\n Initializing...");
  Serial.println(MY_NAME);
  Serial.print("My MAC address is: ");
  Serial.println(WiFi.macAddress());

  WiFi.mode(WIFI_STA);
  connectToWifi();


  initEspNow();
  Serial.println(switchPins[0]);

}


void loop()
{
  if(WiFi.status() != WL_CONNECTED)
   connectToWifi();
   readSwitch();
  //  Serial.println("Starting");
  //  Serial.print("sd2:- ");
  //  Serial.println(digitalRead(9));
  //  delay(2000);
  //  Serial.print("d2:- ");
  //  Serial.println(digitalRead(4));
  //  delay(2000);
  //  Serial.print("d5:- ");
  //  Serial.println(digitalRead(14));
  //  delay(2000);   
  //  Serial.print("d6:- ");
  //  Serial.println(digitalRead(12));
  //  delay(2000);
  //  Serial.print("d7:- ");
  //  Serial.println(digitalRead(13));
  //  delay(2000);     
}
